import time
import serial
from threading import Thread

arduino = serial.Serial('/dev/ttyAMA0', baudrate=115200, timeout=3.0)

class rfidReader(Thread):
    
    def __init__(self, flagL, flagS, txt=""):
        Thread.__init__(self)
        self.flagL = flagL
        self.flagS = flagS
        self.txt = txt

    def run(self):
        
        while(self.flagL == True):
            
            while arduino.inWaiting() > 0:
                self.txt += arduino.read(1)
                self.flagS = False
                time.sleep(0.01)
            if(self.flagS == False):
                print self.txt
                self.flagS = True
                self.txt = ""
                arduino.flush()
                

class convertCode:
   
    def __init__(self, rCode, tLOn, tLOff, tChOff, rBike, flag=True, txt=""):
        self.requestCode = rCode
        self.turnLightsOn = tLOn
        self.turnLightsOff = tLOff
        self.turnChargersOff = tChOff
        self.releaseBike = rBike
        self.flag = flag
        self.txt = txt 

    def sendData(self):
        while (rfid.flagL == True):
           
            comando = raw_input('introduce un comando:\n')
                  
            if(comando.startswith("releaseBike") == True):
                comando = comando.strip("releaseBike")
                try:
                    comando1 = int(comando)
                    arduino.write("*"+comando+"$")
                    #print "*" + comando + "$"
                                  
                except ValueError:
                    print "Posicion incorrecta, intente de nuevo"
         
                except:
                    print "Error inesperado"

            elif(comando == w.requestCode):
                arduino.write("*R$")
                #print "*R$"

            elif(comando == w.turnLightsOn):
                arduino.write("*E$")
                #print "*E$"
      
            elif(comando == w.turnLightsOff):
                arduino.write("*A$")
                #print "*A$"

            elif(comando == w.turnChargersOff):
                arduino.write("*C$")
                #print "*C$"
      
            elif(comando == "go_out"):
                rfid.flagL = False
                #print rfid.flagL
    
            else:
                print "Codigo incorrecto, intente de nuevo"
            time.sleep(2)

if __name__ == "__main__":

    w = convertCode("requestCode", "turnLightsOn", "turnLightsOff", "turnChargersOff", "releaseBike")
    rfid = rfidReader(True, True)
    rfid.start()
    w.sendData()
    
    






